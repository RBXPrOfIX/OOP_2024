"""
This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <https://unlicense.org>
"""
import os
import numpy as np
import tensorflow as tf
from PIL import Image
from keras.applications.resnet50 import ResNet50, preprocess_input, decode_predictions

# Directory containing images
IMAGE_DIR = "images"

# Original images will be resized to this size
IMAGE_SIZE = (224, 224)

# Number of top predictions to print
PREDICTIONS_TOP = 3

# Supported image formats
SUPPORTED_EXTENSIONS = ('.jpg', '.jpeg', '.png')


def classify_image(image_path: str):
    """
    Classifies an image using the ResNet50 model
    :param image_path: path to the image file
    :return: list of predictions
    """
    try:
        image = Image.open(image_path)
        image = image.resize(IMAGE_SIZE)
        image = np.array(image)

        # Convert the image to a TensorFlow tensor
        img_tensor = tf.convert_to_tensor(image)

        # Add a batch dimension
        img_batch = tf.expand_dims(img_tensor, axis=0)

        # Preprocess the image
        img_preprocessed = preprocess_input(img_batch)

        # Load the ResNet50 model
        model = ResNet50(weights="imagenet")

        # Make a prediction
        prediction_ = model.predict(img_preprocessed)

        # Decode the prediction
        predictions = decode_predictions(prediction_, top=PREDICTIONS_TOP)

        return predictions[0]
    except Exception as e:
        print(f"Error processing image {image_path}: {e}")
        return None


def process_directory(directory: str):
    """
    Recursively processes all images in the directory
    :param directory: path to the directory
    """
    for root, _, files in os.walk(directory):
        for file in files:
            if file.lower().endswith(SUPPORTED_EXTENSIONS):
                image_path = os.path.join(root, file)
                print(f"\nClassifying image: {image_path}")
                predictions = classify_image(image_path)
                if predictions:
                    for pred in predictions:
                        print(f"  {pred[1]}: {pred[2]:.2%}")


if __name__ == "__main__":
    process_directory(IMAGE_DIR)
