"""
This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <https://unlicense.org>
"""
from transformers import ViTImageProcessor, ViTForImageClassification
from PIL import Image
import torch
import torch.nn.functional as F
import os

# Load the model and feature extractor
feature_extractor = ViTImageProcessor.from_pretrained("google/vit-base-patch16-224-in21k")
model = ViTForImageClassification.from_pretrained("akahana/vit-base-cats-vs-dogs")

# Labels for the classes
labels = ["cat", "dog"]


def classify_image(image_path: str) -> None:
    """
    Classify a single image as cat or dog.
    """
    try:
        # Load and process the image
        image = Image.open(image_path)
        inputs = feature_extractor(images=image, return_tensors="pt")

        # Predict
        outputs = model(**inputs)
        logits = outputs.logits

        # Apply softmax to get probabilities
        probabilities = F.softmax(logits, dim=1)

        # Get the predicted class
        predicted_class = torch.argmax(probabilities, dim=1).item()
        predicted_label = labels[predicted_class]

        # Print the result
        print(f"Image: {image_path}")
        print(f"Predicted Label: {predicted_label}")
        print(f"Probabilities: {probabilities}")
        print("-" * 50)

    except Exception as e:
        print(f"Error processing {image_path}: {e}")
        print("-" * 50)


def process_directory(directory: str) -> None:
    """
    Recursively process all images in a directory.
    """
    for root, _, files in os.walk(directory):
        for file in files:
            if file.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')):
                image_path = os.path.join(root, file)
                classify_image(image_path)


def main() -> None:
    # Directories to process
    cat_directory = "kagglecatsanddogs_5340/PetImages/Cat"
    dog_directory = "kagglecatsanddogs_5340/PetImages/Dog"

    print("Processing cat images...")
    process_directory(cat_directory)

    print("Processing dog images...")
    process_directory(dog_directory)


if __name__ == "__main__":
    main()
