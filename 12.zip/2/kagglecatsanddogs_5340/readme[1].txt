For information see http://research.microsoft.com/en-us/projects/asirra/corpus.aspx

Contact: jelson
